import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.io.IOException;

public class WAWDT {
  record Item(String category, String title, Set<String> tags, String rating, int minutes) {}
  record Player(String name, List<String> favorites) {}
  record Match(Item item, int score, String reason) {}
  static final List<Item> CATALOG = new ArrayList<>();
  static final Map<String,String> MOODS = Map.of("Funny","funny", "Relaxing","relaxing", "Adventurous","adventurous", "Exciting","exciting", "Family Friendly","family");
  public static void main(String[] args) throws Exception {
    Path path = Path.of("backend", "catalog.tsv");
    if (!Files.exists(path)) path = Path.of("catalog.tsv");
    for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
      String[] cols = line.split("\\t");
      if(cols.length == 5) CATALOG.add(new Item(cols[0],cols[1],new HashSet<>(Arrays.asList(cols[2].split(" "))),cols[3],Integer.parseInt(cols[4])));
    }
    HttpServer server = HttpServer.create(new InetSocketAddress(8080),0);
    server.createContext("/api/health", e -> send(e,200,"{\"ok\":true,\"catalogSize\":"+CATALOG.size()+"}"));
    server.createContext("/api/recommend", e -> {
      if(e.getRequestMethod().equals("OPTIONS")){send(e,204,"");return;}
      if(!e.getRequestMethod().equals("POST")){send(e,405,"{\"error\":\"Use POST\"}");return;}
      try {
        String body = new String(e.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
        String category = field(body,"category"); String mood = field(body,"mood"); String time = field(body,"time");
        List<Player> players = players(body);
        if(players.isEmpty()){send(e,400,"{\"error\":\"Select at least one profile\"}");return;}
        if(players.size()>4){send(e,400,"{\"error\":\"Maximum four players\"}");return;}
        List<Match> matches = recommend(category,mood,time,players);
        StringBuilder out = new StringBuilder("{\"recommendations\":[");
        for(int i=0;i<matches.size();i++){
          Match m=matches.get(i); if(i>0)out.append(',');
          out.append("{\"title\":").append(json(m.item.title)).append(",\"category\":").append(json(m.item.category)).append(",\"matchScore\":").append(m.score).append(",\"reason\":").append(json(m.reason)).append(",\"ageRating\":").append(json(m.item.rating)).append('}');
        }
        send(e,200,out.append("]}").toString());
      } catch(Exception ex){ex.printStackTrace();send(e,400,"{\"error\":\"Invalid request\"}");}
    });
    server.start(); System.out.println("Backend running at http://localhost:8080 ("+CATALOG.size()+" catalog entries)");
  }
  static List<Match> recommend(String category,String mood,String time,List<Player> players){
    String moodTag=MOODS.getOrDefault(mood,"");
    int limit=switch(time){case "30 minutes" -> 30;case "1 hour" -> 60;case "2 hours" -> 120;default -> Integer.MAX_VALUE;};
    List<Match> result=new ArrayList<>();
    for(Item item:CATALOG){
      if(!category.equals("Surprise Us")&&!category.equals(item.category))continue;
      if(!moodTag.isEmpty()&&!item.tags.contains(moodTag))continue;
      if(item.minutes>limit)continue;
      int total=0, supported=0; boolean alreadyFavorite=false;
      for(Player player:players){
        int personal=0;
        for(String fav:player.favorites){
          if(fav.equalsIgnoreCase(item.title)){alreadyFavorite=true;continue;}
          for(Item known:CATALOG)if(known.title.equalsIgnoreCase(fav)){
            Set<String> shared=new HashSet<>(item.tags);shared.retainAll(known.tags);
            personal=Math.max(personal,shared.size()*12+(known.category.equals(item.category)?9:0));
          }
          Set<String> titleWords=new HashSet<>(Arrays.asList(fav.toLowerCase().split("[^a-z0-9]+")));
          for(String word:item.title.toLowerCase().split("[^a-z0-9]+"))if(word.length()>4&&titleWords.contains(word))personal=Math.max(personal,18);
        }
        if(personal>0)supported++;
        total+=Math.min(42,personal);
      }
      if(alreadyFavorite)continue;
      int score=Math.min(98,52+(moodTag.isEmpty()?0:14)+(limit==Integer.MAX_VALUE?0:7)+total/players.size()+supported*3);
      String reason=(supported>0?"Fits favorites from "+supported+" of "+players.size()+" selected player(s). ":"A fresh pick for your group. ")+
          (moodTag.isEmpty()?"": "Matches your "+mood.toLowerCase()+" mood. ")+
          "About "+item.minutes+" minutes"+(item.category.equals("TV Series")?" per episode":"")+".";
      result.add(new Match(item,score,reason));
    }
    result.sort(Comparator.comparingInt(Match::score).reversed().thenComparing(m->m.item.title));
    return result.subList(0,Math.min(12,result.size()));
  }
  static List<Player> players(String json){
    List<Player> out=new ArrayList<>();
    Matcher objects=Pattern.compile("\\{\\s*\"name\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"([^{}]*)\\}").matcher(json);
    while(objects.find()){
      String obj=objects.group(2); List<String> favs=new ArrayList<>();
      for(String key:List.of("favoriteMovies","favoriteVideoGames","favoriteTvShows")){
        Matcher a=Pattern.compile("\""+key+"\"\\s*:\\s*\\[([^]]*)\\]").matcher(obj);
        if(a.find()) {Matcher strings=Pattern.compile("\"((?:\\\\.|[^\"\\\\])*)\"").matcher(a.group(1));while(strings.find())favs.add(unescape(strings.group(1)));}
      }
      out.add(new Player(unescape(objects.group(1)),favs));
    }
    return out;
  }
  static String field(String body,String key){Matcher m=Pattern.compile("\""+key+"\"\\s*:\\s*\"([^\"]*)\"").matcher(body);return m.find()?m.group(1):"";}
  static String unescape(String s){return s.replace("\\\"","\"").replace("\\n"," ").replace("\\\\","\\");}
  static String json(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ")+"\"";}
  static void send(HttpExchange e,int status,String body)throws IOException{
    e.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
    e.getResponseHeaders().set("Access-Control-Allow-Origin","*");
    e.getResponseHeaders().set("Access-Control-Allow-Methods","GET, POST, OPTIONS");
    e.getResponseHeaders().set("Access-Control-Allow-Headers","Content-Type");
    byte[] bytes=body.getBytes(StandardCharsets.UTF_8);e.sendResponseHeaders(status,status==204?-1:bytes.length);
    if(status!=204)e.getResponseBody().write(bytes);e.close();
  }
}
