# What Are We Doing Tonight?

React + TypeScript frontend connected to a Java HTTP backend.

## Requirements
- Java JDK 17 or newer (`java -version` and `javac -version`)
- Node.js 20.19+ or 22.12+ and npm

## Run on Windows (two PowerShell terminals)

**Terminal 1, from the project folder:**
```powershell
javac backend/WAWDT.java
java -cp backend WAWDT
```
Backend: http://localhost:8080/api/health (should show `{"ok":true}`)

**Terminal 2, from the project folder:**
```powershell
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173). Select your preferences and click **Find Our Perfect Match**.

The frontend uses Vite's `/api` proxy to reach the Java backend on port 8080. The Java backend currently returns the three **sample movie recommendations** from the supplied WAWDT.java for every category/mood/time selection. The preferences are sent and logged by the backend but do not yet affect the results. No AI or live recommendations are integrated.

If `java` or `javac` is not recognized, install JDK 17+ and restart PowerShell. If `npm` is not recognized, install Node.js and restart PowerShell.


## Vaporwave design
The frontend uses the provided vaporwave image as its background, neon styling, and cursor-reactive tilt/glow buttons. Start the Java backend with `javac backend/WAWDT.java` and `java -cp backend WAWDT`. In a second terminal run `cd frontend`, `npm.cmd install`, `npm.cmd run dev`. Open http://localhost:5173. The recommendation endpoint currently returns sample data.

## Profiles sidebar
Open **☰ Profiles** to create, edit, select, and delete user profiles. Enter favorite movies, video games, and TV shows (one per line). Profiles are stored in this browser's localStorage, not in the Java backend, so they are not shared between devices or browser profiles. The selected profile and favorites are included in the POST request to `/api/recommend`, but the current Java backend still returns fixed demo recommendations and does not personalize results yet.
